git clone https://nol.cs.nctu.edu.tw:234/open-source/TrackNetv2

pip install keras numpy<1.23.0 tensorflow==2.10.0